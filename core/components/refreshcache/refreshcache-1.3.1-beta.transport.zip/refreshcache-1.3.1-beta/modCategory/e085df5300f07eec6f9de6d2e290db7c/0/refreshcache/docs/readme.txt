----------------------
Snippets: RefreshCache
----------------------
Author: Bob Ray <http://bobsguides.com>

Official Documentation: https://bobsguides.com/refreshcache-tutorial.html
Bugs and Feature Requests: https://github.com/BobRay/RefreshCache
Questions: http://communith.modx.com
